'use strict';

module.exports = require('./core/');