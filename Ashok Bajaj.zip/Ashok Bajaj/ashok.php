<!DOCTYPE html>
<html>
<head>
	<title>Ashok Bajaj</title>
	<style>
		.img{width: 100%; height: 500px;}
	</style>
</head>
<body>
<center><h2>Ashok Bajaj</h2></center>
<img src="360 Panorama View.jpg" class="img">
</body>
</html>