<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel ="stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
	<style>
		.container{background-color: black; width: 500px; height: 1000px;}
		.d-block{ width: 50%;margin-left: 25%; }
		h2{color: white;}h3{color: white; margin-top: 25px; float: left; width: 250px;}
		.border{text-shadow: 2px 2px white; box-shadow: 2px 2px red;}
		.toast{width: 100px; height: 285px; float: right;}
		.active{width: 150px; height: 360px; float: right; margin-top: 20px;}
		h4{color: white; margin-top: 25px; float: left; width: 280px; height: 285px;}
	</style>
</head>
<body style="height: 500px;">
<div class="container">
	<img src="Images/coracle.png" class="d-block">
	<hr class="bg-info"/><br>
	<div style=" width: 250px; height: 100px; margin-left: 16%;">
	<h2 class="border border-danger h-50 text-center">Are you worry ?</h2>
	</div>
	<div class="">
		<h3> Are you Looking trademasks for you busniess ?<hr style="background-color: red;"></h3><img src="Images/Capture.jpg" class="toast">
		<br>
		<h3>Wants to know How you can ?<hr style="height: 6px; background-color: red;"></h3>
	</div>

	<div>
	<img src="images/cust.jpg" class="active">
	<h4>Don't worry ?<hr class="w-100"/ style="background-color: red;">
	Join our 2 day workshop on Trade mark importance for your dream bussniess.<hr class="w-100"/ style="background-color: red;"><br>Call us or Register on website +9250962229 <hr style="background-color: red;"/><h3 style="text-align: center;margin-left: 20%;">www.coracle.in</h3> </h4>
	</div>
	

	
</div>
</body>
</html>